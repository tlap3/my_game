[English version]

Software End-User License Agreement

Game: Target Mania: Boss Alert

Developer: viparit Lapirattanakul

By installing or using this software, you agree to the following terms:

1.License Grant: The Developer grants you a personal, non-exclusive license to use this software for entertainment purposes only.

2.Restrictions:
	2.1You may not modify, reverse engineer, or attempt to decompile the source code of this software.
	2.2You may not redistribute or resell any part of this software without explicit permission.

3.Disclaimer of Warranty: This software is provided "AS-IS" without any warranty. The Developer shall not be liable for any damages arising from the use of this software.

4.Ownership: All rights, titles, and interests in and to the software (including code, graphics, and audio) remain with the Developer.

====================================================================================================================

[Thai version]

ข้อตกลงการใช้งานซอฟต์แวร์ (End-User License Agreement - EULA)

เกม: Target Mania: Boss Alert

ผู้พัฒนา: viparit Lapirattanakul

โดยการติดตั้งหรือใช้งานซอฟต์แวร์นี้ ถือว่าคุณยอมรับข้อตกลงดังต่อไปนี้:

1.สิทธิ์การใช้งาน: ผู้พัฒนาอนุญาตให้คุณใช้งานซอฟต์แวร์นี้เพื่อความบันเทิงส่วนบุคคลเท่านั้น (Personal, non-exclusive license)

2.ข้อห้าม:
	2.1ห้ามดัดแปลง, ทำวิศวกรรมย้อนกลับ (Reverse Engineer), หรือพยายามถอดรหัสซอร์สโค้ดของซอฟต์แวร์นี้
	2.2ห้ามนำไฟล์ส่วนใดส่วนหนึ่งของเกมไปขายต่อหรือแจกจ่ายโดยไม่ได้รับอนุญาตจากผู้พัฒนา

3.การรับประกัน: ซอฟต์แวร์นี้จัดทำขึ้น "ตามสภาพที่เป็นอยู่" (As-Is) โดยไม่มีการรับประกันใดๆ ผู้พัฒนาจะไม่รับผิดชอบต่อความเสียหายใดๆ ที่อาจเกิดขึ้นจากการใช้งานซอฟต์แวร์นี้บนเครื่องคอมพิวเตอร์ของคุณ

4.สิทธิ์ในทรัพย์สินทางปัญญา: เนื้อหา, กราฟิก, เสียง และโค้ดทั้งหมดภายในเกมนี้เป็นสิทธิ์ขาดของผู้พัฒนาแต่เพียงผู้เดียว (เว้นแต่จะระบุไว้เป็นอย่างอื่นสำหรับ Library ภายนอก)