from setuptools import setup
from Cython.Build import cythonize

setup(
    ext_modules = cythonize(["effects.py", "entities.py", "settings.py"]),
)
