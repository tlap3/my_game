# -*- coding: utf-8 -*-

import pygame
import random
import math
import os
from settings import *

# โหลดรูปภาพบอสไว้รอเรียกใช้
boss_imgs = []
def load_boss_assets():
    global boss_imgs
    boss_imgs = []
    try:
        for i in range(1, 4):
            img_path = os.path.join(BASE_PATH, f"boss{i}.png")
            img = pygame.image.load(img_path).convert_alpha()
            boss_imgs.append(img)
    except: pass

class Boss:
    def __init__(self):
        self.type_idx = random.randint(0, 2)
        names = ["GOLIATH", "PHANTOM", "TITAN"]
        self.name = names[self.type_idx]
        self.size = 150
        self.image = pygame.transform.scale(boss_imgs[self.type_idx], (self.size, self.size)) if boss_imgs else None
        self.x, self.y, self.target_y = WIDTH // 2, -150, 150
        self.hp = 15 + (self.type_idx * 5)
        self.max_hp = self.hp
        self.speed_x = 4 + (self.type_idx * 2)
        self.points = 300 + (self.type_idx * 100)
    def move(self):
        if self.y < self.target_y: self.y += 3
        else:
            self.x += self.speed_x
            if self.x < 100 or self.x > WIDTH - 100: self.speed_x *= -1
    def draw(self, surf):
        if self.image: surf.blit(self.image, self.image.get_rect(center=(int(self.x), int(self.y))))
        else: pygame.draw.rect(surf, (50, 50, 50), (self.x - 75, self.y - 75, 150, 150))
        pygame.draw.rect(surf, BLACK, (self.x - 75, self.y - 100, 150, 10))
        pygame.draw.rect(surf, RED, (self.x - 75, self.y - 100, (self.hp / self.max_hp) * 150, 10))

class Target:
    def __init__(self):
        self.shape_type = random.choice(["circle", "square", "star"])
        self.size = random.randint(30, 60)
        self.color = (random.randint(0, 100), random.randint(100, 255), random.randint(150, 255))
        self.x = random.choice([-50, WIDTH + 50])
        self.y = random.randint(150, HEIGHT - 150)
        self.points = 10 if self.shape_type == "circle" else 20 if self.shape_type == "square" else 50
        self.speed = random.randint(4, 9) * (1 if self.x < 0 else -1)
    def move(self): self.x += self.speed
    def draw(self, surf):
        if self.shape_type == "circle": pygame.draw.circle(surf, self.color, (int(self.x), int(self.y)), self.size // 2)
        elif self.shape_type == "square": pygame.draw.rect(surf, self.color, (int(self.x-self.size//2), int(self.y-self.size//2), self.size, self.size))
        elif self.shape_type == "star":
            pts = [(self.x + (self.size // 2 if i % 2 == 0 else self.size // 4) * math.cos(math.radians(i * 36)), self.y + (self.size // 2 if i % 2 == 0 else self.size // 4) * math.sin(math.radians(i * 36))) for i in range(10)]
            pygame.draw.polygon(surf, self.color, pts)