# -*- coding: utf-8 -*-

#settings.py (เก็บค่าคงที่และสี)

import pygame
import os
import sys

# --- การจัดการ Path (หัวใจสำคัญของการย้ายเครื่อง) ---
# ตรวจสอบว่าโปรแกรมรันจากไฟล์ปกติ หรือไฟล์ .exe (PyInstaller)
if getattr(sys, 'frozen', False):
    # ถ้าเป็นไฟล์ .exe ให้หาไฟล์ในโฟลเดอร์ที่ตัว .exe วางอยู่
    BASE_PATH = os.path.dirname(sys.executable)
else:
    # ถ้าเป็นไฟล์ .py ปกติ ให้หาไฟล์ในโฟลเดอร์ปัจจุบัน
    BASE_PATH = os.path.dirname(os.path.abspath(__file__))

# กำหนดที่อยู่ของไฟล์บันทึกคะแนนสูงสุด
SCORE_FILE = os.path.join(BASE_PATH, "highscore.txt")

# --- ตั้งค่าหน้าจอ ---
WIDTH, HEIGHT = 800, 600

# --- สถานะเกม ---
START = 0
PLAYING = 1
GAME_OVER = 2

# --- การตั้งค่าสี (RGB) ---
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED   = (255, 50, 50)
GOLD  = (255, 215, 0)
BLUE  = (0, 100, 255)
GRAY  = (100, 100, 100)
CYAN  = (0, 255, 255)
NEON_YELLOW = (255, 255, 0)

# --- ข้อมูลเพิ่มเติม ---
# คุณสามารถเพิ่มค่าคงที่อื่นๆ เช่น เวลาเล่น หรือ เลือดบอส ไว้ที่นี่ได้
GAME_TIME = 30  # วินาที
BOSS_SPAWN_INTERVAL = 100 # ทุกๆกี่คะแนนบอสถึงจะออก