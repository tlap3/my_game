# -*- coding: utf-8 -*-

#ไฟล์ effects.py (เก็บคลาส ScreenFlash, Announcement, Particle, FloatingScore)

import pygame
import math
import random
from settings import *

class ScreenFlash:
    def __init__(self):
        self.alpha, self.timer, self.active = 0, 0, False
    def trigger(self): self.active, self.timer = True, 0
    def update(self):
        if self.active:
            self.timer += 0.1
            self.alpha = abs(int(math.sin(self.timer * 5) * 100))
            if self.timer > 3: self.active, self.alpha = False, 0
    def draw(self, surface):
        if self.active:
            s = pygame.Surface((WIDTH, HEIGHT)); s.set_alpha(self.alpha); s.fill((255, 0, 0))
            surface.blit(s, (0, 0))

class BossAnnouncement:
    def __init__(self, name):
        self.name, self.alpha, self.active, self.display_timer = f"!!! WARNING: {name.upper()} !!!", 255, True, 120
    def update(self):
        if self.display_timer > 0: self.display_timer -= 1
        else:
            self.alpha -= 5
            if self.alpha <= 0: self.active = False
    def draw(self, surface, font):
        if self.active:
            for dx, dy in [(-2, -2), (2, -2), (-2, 2), (2, 2)]:
                out = font.render(self.name, True, BLACK); out.set_alpha(self.alpha)
                surface.blit(out, out.get_rect(center=(WIDTH // 2 + dx, 80 + dy)))
            txt = font.render(self.name, True, NEON_YELLOW); txt.set_alpha(self.alpha)
            surface.blit(txt, txt.get_rect(center=(WIDTH // 2, 80)))

class Particle:
    def __init__(self, x, y, color):
        self.x, self.y, self.color, self.vx, self.vy, self.alpha = x, y, color, random.uniform(-6, 6), random.uniform(-8, 2), 255
    def move(self): self.vy += 0.4; self.x += self.vx; self.y += self.vy; self.alpha -= 10
    def draw(self, surf):
        if self.alpha > 0:
            s = pygame.Surface((10, 10), pygame.SRCALPHA); pygame.draw.circle(s, (*self.color, self.alpha), (5, 5), 4); surf.blit(s, (int(self.x), int(self.y)))

class FloatingScore:
    def __init__(self, x, y, points, color):
        self.x, self.y, self.points, self.color, self.alpha = x, y, points, color, 255
    def update(self): self.y -= 2; self.alpha -= 5
    def draw(self, surf, font):
        if self.alpha > 0:
            s = font.render(f"+{self.points}", True, self.color); s.set_alpha(self.alpha); surf.blit(s, (self.x, self.y))