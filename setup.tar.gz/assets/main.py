# -*- coding: utf-8 -*-
import pygame
import random
import os
import sys
import asyncio  # Required for Pygbag (Web Version)
from settings import *
from effects import ScreenFlash, BossAnnouncement, Particle, FloatingScore
from entities import Boss, Target, load_boss_assets

# --- Data Management ---
def get_high_score():
    if not os.path.exists(SCORE_FILE): return 0
    with open(SCORE_FILE, "r") as f:
        try:
            return int(f.read())
        except:
            return 0

def save_high_score(new_score):
    if new_score > get_high_score():
        with open(SCORE_FILE, "w") as f: 
            with open(SCORE_FILE, "w") as f: f.write(str(new_score))

# --- Global Variables for Reset ---
score = 0
targets = []
particles = []
floating_scores = []
boss = None
boss_threshold = 100
start_ticks = 0
boss_announcement = None
flash = None

def reset_game():
    global score, targets, particles, floating_scores, boss, boss_threshold, start_ticks, boss_announcement, flash
    score, boss_threshold = 0, 100
    targets, particles, floating_scores = [], [], []
    boss, boss_announcement = None, None
    flash = ScreenFlash()
    start_ticks = pygame.time.get_ticks()

# --- Main Async Function ---
async def main():
    global current_state, score, targets, particles, floating_scores, boss, boss_threshold, start_ticks, boss_announcement, flash
    
    pygame.init()
    pygame.mixer.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Target Mania: Boss Alert")
    clock = pygame.time.Clock()
    
    current_state = START
    load_boss_assets()

    # Load Sounds
    try:
        hit_sound = pygame.mixer.Sound(os.path.join(BASE_PATH, "gunshot.ogg"))
        laugh_sound = pygame.mixer.Sound(os.path.join(BASE_PATH, "evil-laugh.ogg"))
    except:
        hit_sound = laugh_sound = None
        print("Warning: Sound files not found.")

    reset_game()
    font = pygame.font.SysFont("Arial", 32, bold=True)
    big_font = pygame.font.SysFont("Arial", 60, bold=True)

    # --- Main Loop ---
    running = True
    while running:
        screen.fill((240, 240, 240))
        mx, my = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if current_state == START:
                    current_state = PLAYING
                    reset_game()
                elif current_state == GAME_OVER:
                    current_state = START
                elif current_state == PLAYING:
                    if boss:
                        if abs(mx - boss.x) < boss.size // 2 and abs(my - boss.y) < boss.size // 2:
                            boss.hp -= 1
                            if hit_sound: hit_sound.play()
                            for _ in range(10): particles.append(Particle(mx, my, GOLD))
                            if boss.hp <= 0:
                                score += boss.points
                                floating_scores.append(FloatingScore(boss.x, boss.y, boss.points, GOLD))
                                for _ in range(50): particles.append(Particle(boss.x, boss.y, GOLD))
                                boss = None
                                boss_threshold = score + 100
                    else:
                        for t in targets[:]:
                            if abs(mx - t.x) < t.size // 2 and abs(my - t.y) < t.size // 2:
                                score += t.points
                                if hit_sound: hit_sound.play()
                                for _ in range(15): particles.append(Particle(mx, my, t.color))
                                floating_scores.append(FloatingScore(t.x, t.y, t.points, t.color))
                                targets.remove(t)

        # --- UI Rendering ---
        if current_state == START:
            screen.blit(big_font.render("TARGET MANIA", True, BLACK), (180, 180))
            screen.blit(font.render("--- BOSS ALERT ---", True, RED), (280, 260))
            screen.blit(font.render(f"High Score: {get_high_score()}", True, GOLD), (300, 340))
            screen.blit(font.render("Click to Start", True, BLUE), (310, 420))

        elif current_state == PLAYING:
            t_left = max(0, GAME_TIME - (pygame.time.get_ticks() - start_ticks) // 1000)
            if t_left <= 0:
                save_high_score(score)
                current_state = GAME_OVER

            if score >= boss_threshold and boss is None:
                boss = Boss()
                targets.clear()
                boss_announcement = BossAnnouncement(boss.name)
                flash.trigger()
                if laugh_sound: laugh_sound.play()

            flash.update()
            if boss:
                boss.move()
                boss.draw(screen)
                if boss_announcement and boss_announcement.active:
                    boss_announcement.update()
                    boss_announcement.draw(screen, big_font)
            else:
                if len(targets) < 5:
                    if random.random() < 0.03: targets.append(Target())
                for t in targets[:]:
                    t.move()
                    t.draw(screen)
                    if t.x < -100 or t.x > WIDTH + 100: targets.remove(t)

            for p in particles[:]:
                p.move()
                p.draw(screen)
                if p.alpha <= 0: particles.remove(p)

            for fs in floating_scores[:]:
                fs.update()
                fs.draw(screen, font)
                if fs.alpha <= 0:
                    floating_scores.remove(fs)

            flash.draw(screen)
            screen.blit(font.render(f"SCORE: {score}", True, BLACK), (20, 20))
            screen.blit(font.render(f"TIME: {t_left}s", True, RED if t_left < 5 else BLUE), (650, 20))

        elif current_state == GAME_OVER:
            screen.blit(big_font.render("GAME OVER", True, RED), (230, 200))
            screen.blit(font.render(f"Final Score: {score}", True, BLACK), (300, 300))
            screen.blit(font.render("Click to Menu", True, BLUE), (310, 380))

        pygame.display.flip()
        clock.tick(60)
        
        # This line is CRITICAL for Pygbag / Web
        await asyncio.sleep(0)

# Run the app
if __name__ == "__main__":
    asyncio.run(main())